# OmniverseAssistant — Version 5

A free, local-first PWA built from your saved Version 4 HTML project.

## Included
- Assistant with clearly labelled programmed offline responses (not a generative AI model).
- Learning, Creative Studio, Projects, Notes, Knowledge Library and Technology Lab.
- Automation Center for reusable manual checklists (no background execution).
- English/Amharic language selector.
- Local browser storage, JSON export and JSON import.
- PWA manifest, icons and service worker for offline app-shell caching.

## Run locally
Open `index.html` in a modern browser for basic testing. PWA installation and service-worker offline caching require HTTPS or localhost; a `file://` preview is not enough.

## Install on Android (PWA)
1. Put the contents of this folder on an HTTPS host (for example, a GitHub Pages site).
2. Open the HTTPS address in Chrome on Android.
3. Open Chrome's three-dot menu and choose **Install app** or **Add to Home screen**.
4. Launch OmniverseAssistant from the new home-screen icon.

## Build an Android APK
The PWA must first be hosted on HTTPS. Then use PWABuilder (https://www.pwabuilder.com/) to validate the manifest and create an Android package. Follow its current Android packaging instructions and signing steps. Keep your signing key private and backed up. An APK is not included in this source ZIP because it must be generated and signed for distribution.

## Data and privacy
Your notes, projects, messages, workflows and knowledge entries are stored in browser localStorage on that device/browser profile. They are not automatically synced or backed up. Use **Export my data as JSON** regularly. Clearing browser data or uninstalling may remove local data.

## Honest limitations
- Offline assistant replies are programmed templates, not an LLM.
- Automations are user-triggered checklists; the app cannot run tasks in the background.
- No Telegram integration, cloud sync, push notifications, or generative AI backend is configured.
- For true AI later, connect a model through a secure backend; never embed a private API key in the app.
